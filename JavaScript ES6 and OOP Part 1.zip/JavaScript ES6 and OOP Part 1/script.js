const recipes = []; // Recipes array
var editFlag = -1; // Edit mode flag

// Update a recipe when the "Add Recipe" button is clicked
// If the recipe is new, then add the recipe to the recipes array 
// Use addRecipes() function to add the new recipe
// Else edit the recipe in the recipes array
// Clear the form's input fields using the clearInputFields() function
// Finally, display the recipes using the displayRecipes() function
document.getElementById('add-recipe-btn').addEventListener('click', function() {
    
    // Create new/updated recipe object
    const recipe = {};
    
    // Retrieve the values entered by the user
    recipe.title = document.getElementById('title').value;
    recipe.ingredients = document.getElementById('ingredients').value;
    recipe.instructions = document.getElementById('instructions').value;

    // DO NOT add recipe when there is NO recipe title
    if(recipe.title !='') {
        // Determine whether the user is editing or adding new recipe
        if (editFlag >= 0 && editFlag < recipes.length) {
            recipes[editFlag] = recipe;
        } else {
            addRecipe(recipe); // Add recipe if has title
        }
    }
    editFlag = -1; // Exit edit mode (default = Add mode) 
    
    // Clear the input fields
    clearInputFields();

    // Update the display
    displayRecipes();

});

// Clear the form's input fields
function clearInputFields() {
    document.getElementById('title').value = '';
    document.getElementById('ingredients').value = '';
    document.getElementById('instructions').value = '';
}

// Add the new recipe to the recipes array
function addRecipe(recipe) {
    recipes.push(recipe); // Add recipe
    displayRecipes(); // Update the display
}

// Display Recipes
function displayRecipes() {

    // Clear Display to start
    document.getElementById('recipes').innerHTML = '';

    // Loop recipes array
    for(var i = 0; i < recipes.length; i++) {
        let {title, ingredients, instructions} = recipes[i];
        // Add the HTML code to unordered list id="recipes"
        document.getElementById('recipes').innerHTML += 
        `<li>
            <p>
                <b>${title}</b>
            </p>
            <p>
                <b>Ingredients:</b>  ${ingredients}
            </p>
            <p>
                <b>Instructions:</b>  ${instructions}
            </p>
            <button onclick="editRecipe(${i})">Edit</button>
            <button onclick="deleteRecipe(${i})">Delete</button>
        </li>`
    }
}

// Edit the recipe object when the Edit button is clicked
function editRecipe(index) {
    document.getElementById('title').value = recipes[index].title;
    document.getElementById('ingredients').value = recipes[index].ingredients;
    document.getElementById('instructions').value = recipes[index].instructions;
    editFlag = index;
}

// Delete the recipe object when the Delete button is clicked
function deleteRecipe(index){
    if (index >= 0 && index < recipes.length) {
        recipes.splice(index, 1); // Remove 1 element at the specified index
        displayRecipes();
    }
}